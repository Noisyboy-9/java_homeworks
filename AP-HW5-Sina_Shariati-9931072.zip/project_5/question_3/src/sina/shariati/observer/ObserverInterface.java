package sina.shariati.observer;

import sina.shariati.news.News;

public interface ObserverInterface {
    void update(News news);
}
