package sina.shariati.enums;

public enum NewsTypeEnum {
    CLUB_NEWS,
    MATCH_NEWS,
    PLAYERS_NEWS
}
