package sina.shariati.exceptions;

public class DuplicateNewsLetterSubscriptionTypeException extends Exception {
    public DuplicateNewsLetterSubscriptionTypeException(String message) {
        super(message);
    }
}
