package sina.shariati.exceptions;

public class InvalidMatchDateException extends Exception {
    public InvalidMatchDateException(String message) {
        super(message);
    }
}
