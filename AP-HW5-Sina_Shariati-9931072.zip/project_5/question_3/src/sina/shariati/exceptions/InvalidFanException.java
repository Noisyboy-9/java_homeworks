package sina.shariati.exceptions;

public class InvalidFanException extends Exception {
    public InvalidFanException(String message) {
        super(message);
    }
}
