package sina.shariati.exceptions;

public class StackUnderFlowException extends Throwable {
    public StackUnderFlowException(String message) {
        super(message);
    }
}
