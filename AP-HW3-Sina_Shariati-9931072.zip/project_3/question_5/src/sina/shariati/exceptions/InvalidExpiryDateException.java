package sina.shariati.exceptions;

public class InvalidExpiryDateException extends Exception {
    public InvalidExpiryDateException(String message) {
        super(message);
    }
}
