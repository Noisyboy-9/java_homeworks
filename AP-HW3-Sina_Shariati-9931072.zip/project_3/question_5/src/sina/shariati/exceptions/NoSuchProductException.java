package sina.shariati.exceptions;

public class NoSuchProductException extends Exception {
    public NoSuchProductException(String message) {
        super(message);
    }
}
